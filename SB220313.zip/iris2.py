import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.metrics import accuracy_score, silhouette_score, adjusted_rand_score, confusion_matrix
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from pandas import ExcelWriter

# Load the iris dataset
iris = load_iris()
x = pd.DataFrame(iris.data, columns=iris.feature_names)
y = pd.DataFrame(iris.target, columns=["target"])
colormap = np.array(['red', 'blue', 'green'])

# Add flower names
flower_names = np.array(['setosa', 'versicolor', 'virginica'])
y['flower'] = y['target'].apply(lambda i: flower_names[i])

# KMeans clustering
kmeans = KMeans(n_clusters=3, random_state=2).fit(x)
kmeans_labels = kmeans.labels_

# EM (Gaussian Mixture) clustering
gm = GaussianMixture(n_components=3, random_state=2).fit(x)
gm_labels = gm.predict(x)

# Gaussian clustering
gaussian = GaussianMixture(n_components=3, random_state=2).fit(x)
gaussian_labels = gaussian.predict(x)

# Agglomerative clustering
agg_clustering = AgglomerativeClustering(n_clusters=3).fit(x)
agg_labels = agg_clustering.labels_

# DBSCAN clustering
dbscan = DBSCAN(eps=0.5, min_samples=5).fit(x)
dbscan_labels = dbscan.labels_

# Plot clustering results
plt.figure(figsize=(15, 10))

plt.subplot(2, 2, 1)
plt.title("KMeans")
plt.scatter(x.iloc[:, 2], x.iloc[:, 3], c=colormap[kmeans_labels])

plt.subplot(2, 2, 2)
plt.title("EM")
plt.scatter(x.iloc[:, 2], x.iloc[:, 3], c=colormap[gm_labels])

plt.subplot(2, 2, 3)
plt.title("Agglomerative Clustering")
plt.scatter(x.iloc[:, 2], x.iloc[:, 3], c=colormap[agg_labels])

plt.subplot(2, 2, 4)
plt.title("DBSCAN")
plt.scatter(x.iloc[:, 2], x.iloc[:, 3], c=colormap[dbscan_labels])

plt.show()

# Calculate and print clustering accuracies
print('KMeans Accuracy:', accuracy_score(y['target'], kmeans_labels))
print('EM Accuracy:', accuracy_score(y['target'], gm_labels))
print('Gaussian Accuracy:', accuracy_score(y['target'], gaussian_labels))
print('Agglomerative Clustering Accuracy:', accuracy_score(y['target'], agg_labels))
print('DBSCAN Accuracy:', accuracy_score(y['target'], dbscan_labels))

# Silhouette Scores
print('KMeans Silhouette Score:', silhouette_score(x, kmeans_labels))
print('EM Silhouette Score:', silhouette_score(x, gm_labels))
print('Agglomerative Clustering Silhouette Score:', silhouette_score(x, agg_labels))
print('DBSCAN Silhouette Score:', silhouette_score(x, dbscan_labels))

# Classification Algorithms
classifiers = {
    "Logistic Regression": LogisticRegression(max_iter=200),
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(n_estimators=100),
    "SVM": SVC(kernel='linear'),
    "KNN": KNeighborsClassifier(n_neighbors=3)
}

for name, clf in classifiers.items():
    clf.fit(x, y['target'])
    predictions = clf.predict(x)
    accuracy = accuracy_score(y['target'], predictions)
    print(f'{name} Accuracy: {accuracy}')

# Highest petal length and width
highest_petal_length = x.iloc[:, 2].max()
highest_petal_width = x.iloc[:, 3].max()
print(f'Highest Petal Length: {highest_petal_length}')
print(f'Highest Petal Width: {highest_petal_width}')

# Most occurrence of flower
most_occurrence = y['flower'].value_counts().idxmax()
print(f'Most Occurring Flower: {most_occurrence}')

# Bar graph for total numbers of flowers
flower_counts = y['flower'].value_counts()
flower_counts.plot(kind='bar', color=['red', 'blue', 'green'])
plt.title('Total Number of Flowers')
plt.xlabel('Flower Type')
plt.ylabel('Count')
plt.savefig('flower_counts.png')
plt.show()

# Save bar graph data to Excel
excel_path = 'flower_counts.xlsx'
with ExcelWriter(excel_path) as writer:
    flower_counts.to_frame('count').to_excel(writer, sheet_name='Sheet1')

print(f'Flower counts saved to {excel_path}')

# Highest sepal length and width
highest_sepal_length = x.iloc[:, 0].max()
highest_sepal_width = x.iloc[:, 1].max()
highest_sepal_length_flower = y.loc[x.iloc[:, 0].idxmax(), 'flower']
highest_sepal_width_flower = y.loc[x.iloc[:, 1].idxmax(), 'flower']
print(f'Highest Sepal Length: {highest_sepal_length} (Flower: {highest_sepal_length_flower})')
print(f'Highest Sepal Width: {highest_sepal_width} (Flower: {highest_sepal_width_flower})')
# section2:
# setosa species
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

def petal_curve(theta, scale=1):
    r = 1.5 + np.cos(2 * theta)  # Petal shape
    x = scale * r * np.cos(theta)
    y = scale * r * np.sin(theta)
    return x, y

# Create figure and axis
fig, ax = plt.subplots(figsize=(4, 5))  # Smaller figure
ax.set_xlim(-2, 2)  # Adjusted limits for smaller flower
ax.set_ylim(-2, 5)
ax.axis("off")

# Thin Stem
stem_x = np.zeros(50)
stem_y = np.linspace(-2, 0.5, 50)  # Adjusted stem height
stem, = ax.plot([], [], color='green', lw=1.2)

# Sepals (Greenish, small leaves at the base of the flower)
sepal_x = np.linspace(-0.4, 0.4, 50)  # Slightly smaller sepals
sepal_y = np.full_like(sepal_x, 1.4)
sepal_fill = ax.fill([], [], color='green', alpha=0.8)[0]

# Petals (Whitish purple, animated bloom)
theta = np.linspace(0, 2 * np.pi, 100)
x, y = petal_curve(theta, scale=1.2)  # Slightly smaller petals

petal1_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]  # Lavender color
petal2_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]
petal3_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]
petal4_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]

# Text display for Sepal details
sepal_text = ax.text(0.6, -1.8, "Species: Setosa\nAvg Sepal Length: 4.99\nAvg Sepal Width: 3.41",
                     fontsize=9, color="black", ha="right", bbox=dict(facecolor='white', alpha=0.6))

def update(frame):
    index = min(frame, len(stem_y))
    stem.set_data(stem_x[:index], stem_y[:index])
    sepal_fill.set_xy(np.column_stack((sepal_x[:index], sepal_y[:index])))

    # Blooming petals
    petal1_fill.set_xy(np.column_stack((x[:frame], y[:frame])))
    petal2_fill.set_xy(np.column_stack((-x[:frame], y[:frame])))
    petal3_fill.set_xy(np.column_stack((y[:frame], x[:frame])))
    petal4_fill.set_xy(np.column_stack((y[:frame], -x[:frame])))
    
    return stem, sepal_fill, petal1_fill, petal2_fill, petal3_fill, petal4_fill, sepal_text

ani = animation.FuncAnimation(fig, update, frames=100, interval=30, blit=True)
plt.show()


# Species: Versicolor

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

def petal_curve(theta, scale=1):
    r = 1.5 + np.cos(2 * theta)  # Petal shape
    x = scale * r * np.cos(theta)
    y = scale * r * np.sin(theta)
    return x, y

# Create figure and axis (Adjusted size for better visibility)
fig, ax = plt.subplots(figsize=(5, 6))  
ax.set_xlim(-2.5, 2.5)  
ax.set_ylim(-3, 5.5)
ax.axis("off")

# Thin Stem
stem_x = np.zeros(50)
stem_y = np.linspace(-3, 0.5, 50)  # Adjusted stem height
stem, = ax.plot([], [], color='green', lw=1.2)

# Sepals (Green, small leaves at the base of the flower)
sepal_x = np.linspace(-0.5, 0.5, 50)  
sepal_y = np.full_like(sepal_x, 1.2)
sepal_fill = ax.fill([], [], color='green', alpha=0.8)[0]

# Petals (Whitish purple, animated bloom)
theta = np.linspace(0, 2 * np.pi, 100)
x, y = petal_curve(theta, scale=1.3)  

petal1_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]  
petal2_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]
petal3_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]
petal4_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]

# Text display for Sepal details (bottom-right)
sepal_text = ax.text(1.2, -2.5, "Species: Versicolor\nAvg Sepal Length: 5.96\nAvg Sepal Width: 2.77",
                     fontsize=9, color="black", ha="right", bbox=dict(facecolor='white', alpha=0.6))

# Text display for species (Always Visible)
species_text = ax.text(0, -3.5, "Species: Versicolor", fontsize=10, color="black", 
                       ha="center", va="bottom")  

def update(frame):
    index = min(frame, len(stem_y))
    stem.set_data(stem_x[:index], stem_y[:index])
    sepal_fill.set_xy(np.column_stack((sepal_x[:index], sepal_y[:index])))

    # Blooming petals
    petal1_fill.set_xy(np.column_stack((x[:frame], y[:frame])))
    petal2_fill.set_xy(np.column_stack((-x[:frame], y[:frame])))
    petal3_fill.set_xy(np.column_stack((y[:frame], x[:frame])))
    petal4_fill.set_xy(np.column_stack((y[:frame], -x[:frame])))

    return stem, sepal_fill, petal1_fill, petal2_fill, petal3_fill, petal4_fill, sepal_text, species_text

ani = animation.FuncAnimation(fig, update, frames=100, interval=30, blit=True)
plt.show()

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

def petal_curve(theta, scale=1):
    r = 1.5 + np.cos(2 * theta)  # Petal shape
    x = scale * r * np.cos(theta)
    y = scale * r * np.sin(theta)
    return x, y

# Create figure and axis (Adjusted size for better visibility)
fig, ax = plt.subplots(figsize=(5, 6))  
ax.set_xlim(-2.5, 2.5)  
ax.set_ylim(-3, 5.5)
ax.axis("off")

# Thin Stem
stem_x = np.zeros(50)
stem_y = np.linspace(-3, 0.5, 50)  # Adjusted stem height
stem, = ax.plot([], [], color='green', lw=1.2)

# Sepals (Green, small leaves at the base of the flower)
sepal_x = np.linspace(-0.5, 0.5, 50)  
sepal_y = np.full_like(sepal_x, 1.2)
sepal_fill = ax.fill([], [], color='green', alpha=0.8)[0]

# Petals (Whitish purple, animated bloom)
theta = np.linspace(0, 2 * np.pi, 100)
x, y = petal_curve(theta, scale=1.3)  

petal1_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]  
petal2_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]
petal3_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]
petal4_fill = ax.fill([], [], color='#D8BFD8', alpha=0.9)[0]

# Text display for Sepal details (bottom-right)
sepal_text = ax.text(1.2, -2.5, "Species: Virginica\nAvg Sepal Length: 6.6\nAvg Sepal Width: 2.98",
                     fontsize=9, color="black", ha="right", bbox=dict(facecolor='white', alpha=0.6))

# Text display for species (Always Visible)
species_text = ax.text(0, -3.5, "Species: Virginica", fontsize=10, color="black", 
                       ha="center", va="bottom")  

def update(frame):
    index = min(frame, len(stem_y))
    stem.set_data(stem_x[:index], stem_y[:index])
    sepal_fill.set_xy(np.column_stack((sepal_x[:index], sepal_y[:index])))

    # Blooming petals
    petal1_fill.set_xy(np.column_stack((x[:frame], y[:frame])))
    petal2_fill.set_xy(np.column_stack((-x[:frame], y[:frame])))
    petal3_fill.set_xy(np.column_stack((y[:frame], x[:frame])))
    petal4_fill.set_xy(np.column_stack((y[:frame], -x[:frame])))

    return stem, sepal_fill, petal1_fill, petal2_fill, petal3_fill, petal4_fill, sepal_text, species_text

ani = animation.FuncAnimation(fig, update, frames=100, interval=30, blit=True)
plt.show()
